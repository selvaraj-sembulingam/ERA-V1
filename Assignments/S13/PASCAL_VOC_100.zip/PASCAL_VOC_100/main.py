import pandas as pd
import os
import shutil

df = pd.read_csv("100examples.csv")
print(df['text'].head())

for index, row in df.iterrows():
    print(row["text"])
    shutil.copy("../PASCAL_VOC/labels/"+row["text"], "./labels")